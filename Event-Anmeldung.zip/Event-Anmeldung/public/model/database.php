<?php
	require_once "config/config.php";

	$database = new mysqli($db_hostname, $db_username, $db_password, $db_database);
?>