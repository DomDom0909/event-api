<?php
	$api_username = "admin";
	$api_password = "sec!ReT423*&";

	$db_hostname = "localhost";
	$db_username = "root";
	$db_password = "";
	$db_database = "event";
?>